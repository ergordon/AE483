clc; clear; close all;

[data, params] = lab4_simulate;
lab4_visualize(data, params, 'movie.mp4');